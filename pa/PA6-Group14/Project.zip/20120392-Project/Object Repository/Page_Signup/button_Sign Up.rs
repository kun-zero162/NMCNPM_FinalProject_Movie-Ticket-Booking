<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Sign Up</name>
   <tag></tag>
   <elementGuidId>1207e894-57e1-469a-9958-b2cf759e06f3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='container_signup_signin']/div/form/button</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>d127eb1f-475b-4604-aafd-52ffcf5b499e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sign Up</value>
      <webElementGuid>f64e7d19-dd0e-4db6-92d4-2e4cdbe9ceb5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;container_signup_signin&quot;)/div[@class=&quot;form-container sign-up-container&quot;]/form[1]/button[1]</value>
      <webElementGuid>b7812c85-edb5-4a1d-bc84-61da8f2241b9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='container_signup_signin']/div/form/button</value>
      <webElementGuid>903d1bdd-276d-44d9-92be-87a399c381dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='or use your email for registration'])[1]/following::button[1]</value>
      <webElementGuid>40d8c040-6042-4a11-a43e-8ee70e091e17</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create Account'])[1]/following::button[1]</value>
      <webElementGuid>d233d3cd-a810-476a-afd6-37467f397873</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in'])[1]/preceding::button[1]</value>
      <webElementGuid>da520b43-f68d-4e35-99ed-e30c109f3bdd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='or use your account'])[1]/preceding::button[1]</value>
      <webElementGuid>da66a781-36ea-497c-993f-cd3ab0feaeaf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sign Up']/parent::*</value>
      <webElementGuid>6d6da143-a38d-4b23-a17a-1edf21d926ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button</value>
      <webElementGuid>f441d58e-359f-4687-b311-e4b6620c032e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Sign Up' or . = 'Sign Up')]</value>
      <webElementGuid>e5cccc35-89cf-4078-8ce4-003a2f7249d9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
