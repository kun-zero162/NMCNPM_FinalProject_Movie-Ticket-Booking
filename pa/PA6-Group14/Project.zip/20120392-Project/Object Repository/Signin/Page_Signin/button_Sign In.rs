<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Sign In</name>
   <tag></tag>
   <elementGuidId>d61c7d69-67df-4b83-bbcf-762e1e03290a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='container_signup_signin']/div[2]/form/button</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>form[name=&quot;sign-in-form&quot;] > button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>e47e0224-f21a-444b-bcae-2e25369c62e6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sign In</value>
      <webElementGuid>55f22bbf-45d6-4ffe-8f8a-0ea02455a3b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;container_signup_signin&quot;)/div[@class=&quot;form-container sign-in-container&quot;]/form[1]/button[1]</value>
      <webElementGuid>8ff11724-07bf-4d85-b209-bf8c2337e8f8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='container_signup_signin']/div[2]/form/button</value>
      <webElementGuid>a6a22c12-25e4-403f-9761-61630d5d4226</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='or use your account'])[1]/following::button[1]</value>
      <webElementGuid>ddbc7ad8-c4f8-4655-8f06-95418eaeb6ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in'])[1]/following::button[1]</value>
      <webElementGuid>c29ca9f7-bcf6-4f42-b8ab-3b0bf8d35941</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Welcome Back!'])[1]/preceding::button[1]</value>
      <webElementGuid>2aefc58e-7ab2-4944-92c6-63187e051966</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign In'])[2]/preceding::button[1]</value>
      <webElementGuid>df89069c-91bd-4483-a2cc-9dda86696231</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sign In']/parent::*</value>
      <webElementGuid>5caa1341-d04d-4981-9ca5-776a6217cbc1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/form/button</value>
      <webElementGuid>fed3ec94-236e-4a90-a1dd-4c78a6472ae5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Sign In' or . = 'Sign In')]</value>
      <webElementGuid>adac64b9-d0a1-4f99-b41b-43f458a0d140</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
